
           #' Example data from class
           #' 
           #' @author Charlie Geyer \email{geyer@umn.edu}
           #' @references\url{http://users.stat.umn.edu/~almquist/3811_examples/gapminder2007ex.csv}  
           "gap" 
           
           #' @author Charlie Geyer \email{geyer@umn.edu}
           #' @references\url{http://www.stat.umn.edu/geyer/3701/data/q1p4.txt}  
           "d" 
           
           #' @author Charlie Geyer \email{geyer@umn.edu}
           #' @references\url{http://users.stat.umn.edu/~almquist/3811_examples/all_alaska_flights.csv}
           "flights" 