library(testthat)
library(LATools)

test_check("LATools")
